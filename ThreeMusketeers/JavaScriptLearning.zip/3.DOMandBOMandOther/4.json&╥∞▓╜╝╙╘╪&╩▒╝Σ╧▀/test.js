var div = document.getElementsByTagName('div')[0];

function test(){
    console.log('a');
}

var tools = {
    test:function (){
        console.log('b');
    },
    demo: function(){

    }
}