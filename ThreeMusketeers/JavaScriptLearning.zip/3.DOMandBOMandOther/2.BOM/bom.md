# BOM:Browser Object Model

## 计时器

