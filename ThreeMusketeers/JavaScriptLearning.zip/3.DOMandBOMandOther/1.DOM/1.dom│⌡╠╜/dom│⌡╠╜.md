# dom初探

## 什么是DOM?
> 就是想通过js操作html

1. DOM — > Document Object Model

2. DOM定义了表示和修改文档所需的对象、这些对象的行为和属性以及这些对象之间的关系。DOM对象即为宿主对象，由浏览器厂商定义，用来操作html和xml功能的一类对象的集合。也有人称DOM是对HTML以及XML的标准编程接口。

- 任何东西都不能直接操作css样式表,但可以**通过操作html行间样式来间接修改css**

3. xml(不能自定义标签,其他功能和html基本一致) --> xhtml --> html

4. 没有-,用小驼峰式命名规则

## dom基本操作




