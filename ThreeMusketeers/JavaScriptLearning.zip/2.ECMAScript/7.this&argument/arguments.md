# arguments

## arguments.callee

> 指向函数自身引用,在哪个函数里,就指向哪个函数
- 所以,可以在立即执行函数里使用它,以便找到函数本身的引用

## func1.caller

- 注意是func1,func1在哪个函数里被调用的,caller就指向哪个函数


