
/**
 * nums：一个数字的数组
 */
var nums = [23, 56, 65, 746];

/**
 * 
 * 两个数求和,下面两行是,指令,实际不会运行,{*}代表是后面的变量的类型,*代表任何类型
 * @param {number} a 第一个数字
 * @param {number} b 第二个数字
 * @returns {Boolean}
 */

/**
 * 判断一个数是不是素数
 * @param {number} n 要判断的数
 * @returns {boolean} 是否是素数
 */
function isPrime(n){
    //..
}

var s = sum(1,3);