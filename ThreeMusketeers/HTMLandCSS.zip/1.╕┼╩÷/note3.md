# 开发环境的准备 {ignore}

[toc]

## 显示文件扩展名

大部分文件，它的文件名：名称.扩展名(后缀名)

扩展名决定了文件被什么应用程序打开。

## 安装浏览器

IE
Opera
Firefox
Chrome【推荐】
Safari

将chrome设置为默认浏览器

## 安装编辑器

windows记事本
Sublime
ATom
Dreamweaver
VSCode【推荐】