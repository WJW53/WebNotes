# 美化表单元素

## 新的伪类

1. focus——元素聚焦时的样子
2. checked——单选或多选框被选中时的样子

## 常见用法

1. 重置表单元素样式

2. 设置textarea(多行文本框)是否允许调整尺寸

- `resize`: horizontal;水平方向可以设置           
- resize: vertical;垂直方向可以设置          
- resize: none;两个方向都不能设置           
- resize: both; 两个方向都可以设置

>但是只有一句能生效

3. 文本框边缘到内容的距离

- `padding:`
- text-indent:

4. 控制单选和多选的样