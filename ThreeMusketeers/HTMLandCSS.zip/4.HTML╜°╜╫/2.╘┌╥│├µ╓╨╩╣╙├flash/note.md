# 在页面中使用flash

如何嵌入flash？下述两个元素任选其一。它俩都是可替换元素！

`object: `

`embed: `

MIME:Multipurpose Internet Mail Extensions，多用途互联网邮件扩展类型

百度百科搜索，ctral+F,可以去搜索后缀名

比如，资源是一个jpg图片，MIME:image/jpeg