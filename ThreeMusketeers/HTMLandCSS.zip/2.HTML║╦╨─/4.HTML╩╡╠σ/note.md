# HTML实体

实体字符，HTML Entity

实体字符通常用于在页面中显示一些特殊符号

1. &单词；
2. &#数字；

- 小于符号

&lt;

- 大于符号

&gt;

- 空格:non-breaking space

&nbsp;

- 版权符号:@

&copy;

- &符号本身

&amp;