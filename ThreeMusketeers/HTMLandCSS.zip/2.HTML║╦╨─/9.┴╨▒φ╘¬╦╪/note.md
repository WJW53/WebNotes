# 列表元素

## 有序列表

父元素ol: ordered list

type属性，除非特别重要(法律等文件条目)，否则应使用CSS的 list-style-type 属性代替

reverse属性，布尔属性

子元素li: list item


## 无序列表

常用于制作菜单

ul: unordered list

li:

## 定义列表

通常用于一些术语的定义

dl: definition list

dt: definition title

dd: definition description