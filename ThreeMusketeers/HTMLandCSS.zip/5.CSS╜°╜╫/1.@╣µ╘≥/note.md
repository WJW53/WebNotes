# @规则

at-rule: @规则、@语句、CSS语句、CSS指令

1. import

书写方式: 

@import "路径";

表示：导入另外一个css文件

2. charset

@charset "utf-8";

告诉浏览器该CSS文件，使用的字符编码集是utf-8,这个指令必须写在css文件第一行