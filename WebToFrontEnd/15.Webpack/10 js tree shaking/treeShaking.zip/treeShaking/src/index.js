import { sum } from './sum';

import './index.css';

console.log(sum(), 'hello world!') 
var div = document.getElementsByTagName('div')[0];
div.innerHTML = '<a>lalllal</a>';