import sum from './sum';
var minus = require('./minus');
import '../src/demo.css';

console.log(sum(3,4));
console.log(minus(12,10));

// var arr = [1,2,3,4,5,6];
// arr.forEach(element => {
//     console.log(element)
// }); 
