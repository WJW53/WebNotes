define(function () {
    var name = 'm1-amd';
    function getName() {
        return name;
    }
    return {getName};
});