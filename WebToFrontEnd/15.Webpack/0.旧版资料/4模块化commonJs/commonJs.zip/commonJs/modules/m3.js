exports.foo = function(){
    return 'm4';
}


// {
//     foo:function
// }