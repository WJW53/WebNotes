module.exports  = {
    msg:'m1',
    foo:function(){
        return this.msg;
    }
}