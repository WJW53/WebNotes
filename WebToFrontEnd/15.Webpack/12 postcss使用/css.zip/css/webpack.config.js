var path = require("path");
var MiniCssExtractPlugin = require("mini-css-extract-plugin");
var Webpack = require("webpack");
var HtmlWebpackPlugin = require('html-webpack-plugin');
var CleanWebpack = require('clean-webpack-plugin');
module.exports = {
    entry: {
        index: './src/index.js',
    },
    output: {
        path: path.resolve(__dirname, "dist"),
        filename: "[name]-[hash:5].bundle.js",
        // publicPath:'/dist'
    },
    module: {
        rules: [
            {
                test: /\.less$/,
                use: [
                    {loader:'style-loader'},
                    // { loader: MiniCssExtractPlugin.loader },
                    { loader: 'css-loader'},
                    {
                        loader: 'postcss-loader',
                        options: {
                            ident: 'postcss',
                            plugins: [
                                // require('autoprefixer')(),
                                require('postcss-cssnext')(),
                                require('cssnano')({
                                    preset: 'default'
                                }), 
                            ]
                        }
                    },
                    { loader: 'less-loader' }],
            },
            {
                test:/\.(png|jpg|jpeg|gif)$/,
                use:[
                    // 转换base64编码或单独抽离图片
                    {
                        loader:'url-loader',
                        options:{
                            name:'[name].min.[ext]',
                            // 限制图片大小  <= 100kb 进行base64编码
                            // limit:100000,
                            limit:1,
                            // 打包后的路径
                            outputPath:'img'
                    }
                    },
                    {
                        loader:'img-loader',
                        options:{
                            plugins:[
                                require('imagemin-pngquant')({
                                    quality:[0.3,0.6]
                                  }),
                            ]
                        }
                    }
                ]
            },
            // 不能处理html中引入的图片  需要用到html-loader
            {
                test:/\.html$/,
                use:[
                    {
                        // 处理html中引入的图片
                        loader:'html-loader',
                        options:{
                            attrs:['img:src']
                        }
                    }
                ]
            }
        ],
    },
    plugins: [
        new MiniCssExtractPlugin({
            // Options similar to the same options in webpackOptions.output
            // both options are optional
            filename: "[name]-[hash:5].css",
            // chunkFilename: "[id].css"
        }),
        new HtmlWebpackPlugin({
            filename:'index.html',
            template:'./index.html',
          
            // 指定文件插入页面中
            // chunks:[],
            minify:{
                // 去掉空格
                // collapseWhitespace:true,
                // 清理注释
                removeComments:true
            }
        }),
        // 每次清除上一次的打包文件
        // new CleanWebpack(),
        new Webpack.HotModuleReplacementPlugin()
    ],
    devServer:{
        // 提供内容的路径
        contentBase:'dist',
        // 修改端口号
        port:'9090',
        // 开启热更新此时会刷新浏览器
        hot:true,
    }
}     