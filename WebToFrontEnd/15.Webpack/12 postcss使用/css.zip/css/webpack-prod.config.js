module.exports = {
    mode:'production'
}