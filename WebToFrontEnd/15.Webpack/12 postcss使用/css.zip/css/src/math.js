function add(){
    console.log('add');
    console.log(1111)
}
export default {
    fn:add
}